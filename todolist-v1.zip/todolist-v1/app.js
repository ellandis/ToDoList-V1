const express = require("express");
const bodyParser = require("body-parser");

//because it is locale
const date = require(__dirname + "/date.js");

const app = express();

const items = ["Thank God", "Meditate", "Educate", "Lift Weights"];
const workItems = [];

app.set('view engine','ejs');
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));

//access the home route
app.get("/", function(req,res){
     //res.sed("hello");
     const day = date.getDate();
     res.render("list",{listTitle: day, newListItems: items});
});

app.post("/", function(req,res){
     const item = req.body.newItem;
     if(req.body.list === "Work"){
          workItems.push(item);
          res.redirect("/work");
     }else{
          items.push(item);
          res.redirect("/");
     }

     //CAUTION TO MANY res.redirect's will cause header malfunction as shown below
     // Error [ERR_HTTP_HEADERS_SENT]: Cannot set headers after they are sent to the client
     //items.push(item);

     //res.redirect("/");
});

//access the work route
app.get ("/work",function(req,res){

     res.render("list",{listTitle: "Work List", newListItems : workItems});
});

app.post("/work",function(req,res){
     const item = req.body.newItem;
     workItems.push(item);
     res.redirect("/work");
})

app.get("/about",function(req,res){
     res.render("about");
})

//server is listening to this port
app.listen(3000,function(){
     console.log("Server started on port 3000");
});
